-- 1.create a database
create database emp;
use emp;
-- 2q:Create a table named Employees with the above 10 columns.Apply appropriate constraints such as:
create table  Employees(
EmployeeID int , -- primary key
firstname varchar(30) ,
lastname varchar(40),
email varchar(50) unique,
PhoneNumber bigint not null,
hiredate varchar(12),
jobtitle varchar(30) default 'employee', -- default
department varchar(20),
salary decimal(10,2),
status varchar(20) check (status in ('oldemployee','working','inactive')), -- check
primary key(employeeid,phonenumber) -- composite key
);
-- 3Q Insert at least 8–10 realistic records into the Employees table
INSERT INTO Employees 
(EmployeeID, firstname, lastname, email, PhoneNumber, hiredate, jobtitle, department, salary, status) 
VALUES
(1, 'Ravi', 'Kumar', 'ravi.kumar@example.com', 9876543210, '2020-01-15', 'Manager', 'HR', 65000.00, 'working'),

(2, 'Sita', 'Reddy', 'sita.reddy@example.com', 9876543211, '2019-03-22', DEFAULT, 'Finance', 55000.50, 'working'),

(3, 'Arjun', 'Varma', 'arjun.varma@example.com', 9876543212, '2021-07-10', 'Developer', 'IT', 48000.75, 'working'),

(4, 'Priya', 'Naidu', 'priya.naidu@example.com', 9876543213, '2018-11-05', DEFAULT, 'Sales', 43000.00, 'oldemployee'),

(5, 'Vikram', 'Singh', 'vikram.singh@example.com', 9876543214, '2022-04-01', 'Team Lead', 'IT', 72000.25, 'working'),

(6, 'Meena', 'Sharma', 'meena.sharma@example.com', 9876543215, '2017-09-18', DEFAULT, 'HR', 39500.00, 'oldemployee'),

(7, 'Kiran', 'Das', 'kiran.das@example.com', 9876543216, '2023-06-12', 'Analyst', 'Finance', 51000.00, 'working'),

(8, 'Anita', 'Rao', 'anita.rao@example.com', 9876543217, '2016-02-27', DEFAULT, 'Admin', 38000.00, 'oldemployee');

-- 4Q Perform SQL Operations:
-- 4Q.1 Display all columns from the Employees table
desc employees;
-- 4Q.2 Find employees with a salary greater than $ 50,000
select firstname,salary from employees where salary>50000;
-- 4Q.3 Use the WHERE clause to display employees from a specific department (e.g., "HR").
select * from employees where department='hr';
-- 4Q.4 Use the ORDER BY clause to sort employees by HireDate in descending order
select * from employees order by hiredate desc;
-- 4Q.5 Find employees whose first names start with a specific letter (e.g., 'A') using the LIKE operator
select * from employees 
where firstname Like 'A%';
-- 4Q.6 Use the BETWEEN operator to find employees hired between two specific dates.
select * from employees 
where hiredate between '2019-03-22' and '2021-07-10';
-- 4Q.7 Use the IN operator to find employees in either the "Sales" or "Finance" departments
select * from employees where department in ('sales','finance');
-- 4Q.8 Update the Status of employees who joined before 2022 to 'Inactive
update employees
set status='inactive'
where hiredate between '2001-01-01' and '2022-01-01';
select * from employees;
-- 4Q.9 Use a CASE statement to categorize employees based on their salary:
select firstname,salary,
case
when salary between 1 and 40000 then 'low'
when salary between 40001 and 70000 then 'medium'
when salary between 70001 and 20000000 then 'high'
end as 'range'
from employees;
-- 4Q.10 Delete all employees whose Status is 'Inactive
delete from employees
where status='inactive';

-- 5Q Alter TableAdd a new column called Bonus (DECIMAL type) to the existing Employees table with a default value of 0
alter table employees
add bonus decimal(10,2);

-- 6Q create second table 
-- 6q.1 Create a new table named Departments.& Add a FOREIGN KEY constraint in the Employees table that references the Departments table.
create table departments(
id int,
experience varchar(20),
foreign key(id) references employees(employeeid));






